# Song-Downloader-Bot

A BOT TO DOWNLOAD SONGS FROM YOUTUBE. 

# Mandatory variables 

- API_ID - Get It From [my.telegram.org](https://my.telegram.org)
- API_HASH - Get It From [my.telegram.org](https://my.telegram.org) 
- BOT_TOKEN - Get It From [@Botfather](https://t.me/BOTFATHER)
- DB_URI - Mongo Database URL from [https://cloud.mongodb.com/](https://cloud.mongodb.com/) 
- OWNER_ID - Get This From [NAZRIYANAZEEMBOT](https://t.me/NAZRIYANAZEEMBOT) By using /id command on bot pm. 


# Feautures 

- Song Downloader. 
- YouTube video Downloader. 
- Lyrics scrapping. 
- Inline YouTube serch. 
- Broadcast Message To users. 

# Credits 

- [Oxidisedman](https://github.com/Oxidisedman). 
- [Muhammed](https://github.com/PR0FESS0R-99). 
- [Pyrogram](https://github.com/pyrogram/pyrogram) and For [Me](https://github.com/MR-JINN-OF-TG). 


# Deploy To Heroku

<details><summary>Deploy To Heroku</summary>
<p>
<br>
<a href="https://heroku.com/deploy?template=https://github.com/MR-JINN-OF-TG/Song-Downloader">
  <img src="https://www.herokucdn.com/deploy/button.svg" alt="Deploy">
</a>
</p>
</details>

# Deploy To Heroku Tutorial 

[CLICK HERE TO WATCH THE VIDEO](https://youtu.be/JEEBTAZFQH0) 


# support Group

- [Click Here To Reach Our Support Group](https://t.me/NAZRIYASUPPORT) 
